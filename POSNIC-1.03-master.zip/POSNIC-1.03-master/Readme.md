# POSNIC
## Intro
* A really simple Point of Sale application based on PHP/MySQL

## Security notes
* Stores passwords in plain text by default
* No cleaning of any POST / GET variables
* PHP 5.3.x and MySQL 5.1 tested

## Installation
* Extract the zip file 
* Copy file to localhost
* Run the project in localhost
* Configure the localhost name, username and password
* Click install button 
* Create a database or select your existing database and click next button
* Upload your store logo
* Enter your store details (with your logo)
* Press Finish
* Enjoy

## If you find any difficulties in installation please modify config.php.sample file and save as config.php.