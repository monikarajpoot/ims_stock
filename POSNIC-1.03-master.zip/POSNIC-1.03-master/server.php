<?php

$data[0] = array(
    'label' => 'sasi',
    'desc' => 'jibi',
    'value' => 'jibi'
);
$data[1] = array(
    'label' => 'sasi',
    'desc' => 'jibi',
    'value' => 'jibi'
);
echo json_encode($data);

?>
